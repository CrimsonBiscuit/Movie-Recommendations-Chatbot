# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
TOGETHER_API_KEY="51ab30a4e5b66a4c6b72ffadad7e57bfa8cbec6b4eddfc4a3d72dd4841724556"